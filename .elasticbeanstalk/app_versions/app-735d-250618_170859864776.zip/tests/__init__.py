"""
Test package for the Diet Fitness application.

This package contains test modules for various components of the application.
"""